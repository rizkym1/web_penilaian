

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <h3 class="mb-4">Daftar Tugas Siswa</h3>

    <div class="card shadow-sm p-4">
        <div class="table-responsive">
            
            <table class="table table-bordered table-hover align-middle text-center">
                <thead class="table-primary">
                    <tr>
                        <th>No</th>
                        <th>Nama Siswa</th>
                        <th>Foto Tugas</th>
                        <th>Tanggal Unggah</th>
                        <th>Status Penilaian</th>
                        <th>Skor Nilai</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $tugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td><?php echo e($item->user->name ?? 'Tidak ada nama'); ?></td>
                            <td>
                                <img src="<?php echo e(asset('storage/' . $item->foto)); ?>" alt="Foto Tugas" width="100">
                            </td>
                            <td>
                                <?php echo e(\Carbon\Carbon::parse($item->created_at)->format('d M Y')); ?>

                            </td>
                            <td>
                                <?php if($item->penilaian): ?>
                                    <span class="badge bg-success text-white">Sudah Dinilai</span>
                                <?php else: ?>
                                    <span class="badge bg-warning text-dark">Belum Dinilai</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($item->penilaian): ?>
                                    <?php
                                        $skor = $item->penilaian->skor_total;
                                        $nilai_akhir = intval($skor * 100 / 28);

                                        if ($skor >= 25) {
                                            $kategori = 'Sangat Baik';
                                        } elseif ($skor >= 19) {
                                            $kategori = 'Baik';
                                        } elseif ($skor >= 13) {
                                            $kategori = 'Cukup';
                                        } elseif ($skor >= 7) {
                                            $kategori = 'Perlu Bimbingan';
                                        } else {
                                            $kategori = 'Belum Dinilai';
                                        }
                                    ?>
                                    <?php echo e($skor); ?> / 28<br>
                                    <small class="text-muted">Nilai: <?php echo e($nilai_akhir); ?></small><br>
                                    <small class="d-block">Kategori: <strong><?php echo e($kategori); ?></strong></small>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                            <td class="d-flex justify-content-center">
                                <!-- Tombol Edit Nilai -->
                                <?php if($item->penilaian): ?>
                                    <a href="<?php echo e(route('penilaian.siswa', $item->id)); ?>" class="btn btn-sm btn-info mx-1" data-bs-toggle="tooltip" data-bs-placement="top" title="Edit Nilai">
                                        <i class="fas fa-pencil-alt"></i> Edit
                                    </a>
                                <?php else: ?>
                                    <a href="<?php echo e(route('penilaian.siswa', $item->id)); ?>" class="btn btn-sm btn-primary mx-1" data-bs-toggle="tooltip" data-bs-placement="top" title="Nilai Tugas">
                                        <i class="fas fa-pen"></i> Nilai
                                    </a>
                                <?php endif; ?>

                                <!-- Tombol Hapus -->
                                <form action="<?php echo e(route('tugas.destroy', $item->id)); ?>" method="POST" style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="button" class="btn btn-sm btn-danger mx-1" onclick="confirmDelete(<?php echo e($item->id); ?>)" data-bs-toggle="tooltip" data-bs-placement="top" title="Hapus Tugas">
                                        <i class="fas fa-trash-alt"></i> Hapus
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7">Belum ada tugas yang dikumpulkan.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    // Konfirmasi penghapusan dengan SweetAlert2
    function confirmDelete(tugasId) {
        Swal.fire({
            title: 'Apakah Anda yakin?',
            text: "Tugas ini akan dihapus permanen!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Hapus',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                // Menghitung form berdasarkan tugasId dan submit
                const form = document.querySelector(`form[action*="${tugasId}"]`);
                form.submit();
            }
        });
    }

    <?php if(session('success')): ?>
        Swal.fire({
            icon: 'success',
            title: 'Berhasil!',
            text: '<?php echo e(session('success')); ?>',
            showConfirmButton: false,
            timer: 2500
        });
    <?php endif; ?>
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sbadmin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\web_penilaian\resources\views/guru/tugas.blade.php ENDPATH**/ ?>