

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <h3 class="mb-4">Daftar Pengguna</h3>

    <div class="card shadow-sm p-4">
        <div class="table-responsive">
            <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary mb-3">
                <i class="fas fa-user-plus"></i> Tambah Pengguna
            </a>
            <table class="table table-bordered table-hover align-middle text-center">
                <thead class="table-primary">
                    <tr>
                        <th>No</th>
                        <th>Nama Pengguna</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                  <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                      <tr>
                          <td><?php echo e($index + 1); ?></td>
                          <td><?php echo e($user->name); ?></td>
                          <td><?php echo e($user->email); ?></td>
                          <td>
                              <span class="badge bg-info text-white"><?php echo e(ucfirst($user->role)); ?></span>
                          </td>
                          <td>
                              <!-- Tombol Edit -->
                              <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="btn btn-sm btn-warning" data-bs-toggle="tooltip" data-bs-placement="top" title="Edit Pengguna">
                                  <i class="fas fa-pencil-alt"></i> Edit
                              </a>
              
                              <!-- Tombol Hapus -->
                              <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="POST" style="display:inline;">
                                  <?php echo csrf_field(); ?>
                                  <?php echo method_field('DELETE'); ?>
                                  <button type="button" class="btn btn-sm btn-danger" onclick="confirmDelete(<?php echo e($user->id); ?>)" data-bs-toggle="tooltip" data-bs-placement="top" title="Hapus Pengguna">
                                      <i class="fas fa-trash-alt"></i> Hapus
                                  </button>
                              </form>
                          </td>
                      </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                      <tr>
                          <td colspan="5">Belum ada pengguna yang terdaftar.</td>
                      </tr>
                  <?php endif; ?>
              </tbody>
              
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    // Konfirmasi penghapusan dengan SweetAlert2
    function confirmDelete(userId) {
        Swal.fire({
            title: 'Apakah Anda yakin?',
            text: "Pengguna ini akan dihapus permanen!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Hapus',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                // Menghitung form berdasarkan userId dan submit
                const form = document.querySelector(`form[action*="${userId}"]`);
                form.submit();
            }
        });
    }

    <?php if(session('success')): ?>
        Swal.fire({
            icon: 'success',
            title: 'Berhasil!',
            text: '<?php echo e(session('success')); ?>',
            showConfirmButton: false,
            timer: 2500
        });
    <?php endif; ?>
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sbadmin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\web_penilaian\resources\views/guru/data-users.blade.php ENDPATH**/ ?>