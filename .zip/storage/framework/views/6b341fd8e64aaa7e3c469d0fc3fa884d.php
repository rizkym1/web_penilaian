

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800">Penilaian Tugas</h1>

    <div class="card shadow mb-4">
        <div class="card-header bg-primary text-white">
            <h6 class="m-0 font-weight-bold">Form Penilaian</h6>
        </div>
        <div class="card-body">
            <h5 class="mb-3">Nama Siswa: <?php echo e($tugas->user->name); ?></h5>

            <img src="<?php echo e(asset('storage/' . $tugas->foto)); ?>" class="img-thumbnail mb-4" width="300">

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form id="formPenilaian" action="<?php echo e(route('penilaian.simpan', $tugas->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="table-responsive">
                    <table class="table table-bordered text-center align-middle">
                        <thead class="table-secondary">
                            <tr>
                                <th>Aspek</th>
                                <th>Skor 4<br><small>Sangat Baik</small></th>
                                <th>Skor 3<br><small>Baik</small></th>
                                <th>Skor 2<br><small>Cukup</small></th>
                                <th>Skor 1<br><small>Perlu Bimbingan</small></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $aspek = [
                                    1 => '1. Pernyataan Umum',
                                    2 => '2. Deretan Penjelas',
                                    3 => '3. Interpretasi / Simpulan',
                                    4 => '4. Penggunaan Konjungsi',
                                    5 => '5. Kalimat Fakta',
                                    6 => '6. Penggunaan Istilah Ilmiah',
                                    7 => '7. Kerapian Tulisan & Ejaan',
                                ];
                            ?>

                            <?php $__currentLoopData = $aspek; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $judul): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-start"><?php echo e($judul); ?></td>
                                <?php for($skor = 4; $skor >= 1; $skor--): ?>
                                <td>
                                    <input
                                        type="checkbox"
                                        name="indikator[<?php echo e($key); ?>][]"
                                        value="<?php echo e($skor); ?>"
                                        class="form-check-input"
                                        id="indikator_<?php echo e($key); ?>_<?php echo e($skor); ?>"
                                        <?php
                                            $indikatorKey = "indikator_$key";
                                            $checked = false;

                                            if (old("indikator.$key") && in_array($skor, old("indikator.$key"))) {
                                                $checked = true;
                                            } elseif (isset($tugas->penilaian) && $tugas->penilaian->$indikatorKey) {
                                                $checked = (int)$tugas->penilaian->$indikatorKey === $skor;
                                            }
                                        ?>
                                        <?php echo e($checked ? 'checked' : ''); ?>

                                    >
                                </td>
                                <?php endfor; ?>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <div class="form-group mt-4">
                    <label for="komentar">Komentar</label>
                    <textarea name="komentar" id="komentar" class="form-control" rows="3"><?php echo e(old('komentar', $tugas->penilaian->komentar ?? '')); ?></textarea>
                </div>

                <button type="button" class="btn btn-success mt-3" id="btnSimpan">Simpan Penilaian</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    // // Tampilkan notifikasi jika penilaian berhasil
    // <?php if(session('success')): ?>
    //     Swal.fire({
    //         icon: 'success',
    //         title: 'Berhasil!',
    //         text: '<?php echo e(session("success")); ?>',
    //         showConfirmButton: false,
    //         timer: 2000
    //     });
    // <?php endif; ?>

    // Konfirmasi sebelum simpan penilaian
    document.getElementById('btnSimpan').addEventListener('click', function(e) {
        Swal.fire({
            title: 'Yakin ingin menyimpan penilaian?',
            text: "Pastikan semua aspek telah dinilai.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#198754',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya, simpan!',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById('formPenilaian').submit();
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sbadmin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\web_penilaian\resources\views/guru/penilaian.blade.php ENDPATH**/ ?>